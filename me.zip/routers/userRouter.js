const router = require("express").Router();
const controller = require('../controllers/userController')
const checkPermission = require('../utils/checkPermission')
var passport = require('passport');

router.post('/', passport.authenticate('jwt',{session: false}), checkPermission, controller.getUsers);
router.get('/:id', controller.getUser)
router.post('/register', controller.registerUser);
router.post('/login', controller.loginUser);
router.post('/delete', passport.authenticate('jwt',{session: false}), checkPermission, controller.deleteUser);


module.exports = router;
