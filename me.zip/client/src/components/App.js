import Router from '../routes/appRouter';
const App = () => <Router/>;
export default App;
